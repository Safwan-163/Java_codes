import java.util.Scanner;

public class Problem_02 {
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        if(a%2==0){
            System.out.println("even");
        }
        else {
            System.out.println("ODD");
        }

    }
}
