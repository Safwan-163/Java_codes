import java.util.Scanner;

public class Problem_03 {

    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int count=0;
        for(int i=2;i<a;i++){
            if(a%i==0){
                count++;
            }
        }
        if(count==0){
            System.out.println("prime");
        }
        else {
            System.out.println("non prime");
        }

    }
}
