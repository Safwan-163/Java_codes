import java.util.Scanner;

public class Problem_04 {

    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);

        int d=sc.nextInt();
        int r=d%7;
        if(r==0){
            System.out.println("Saturday");
        }
        else if(r==1){
            System.out.println("Sunday");
        }
        else if(r==2){
            System.out.println("Monday");
        }
        else if(r==3){
            System.out.println("Tuesday");
        }
        else if(r==4){
            System.out.println("Wednesday");
        }

        else if(r==5){
            System.out.println("Thursday");
        }

        else if(r==6){
            System.out.println("Friday");
        }
        else{
            System.out.println("Day not found");
        }

    }
}
