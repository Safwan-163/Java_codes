import java.util.Scanner;

public class Problem_05 {
    static int gcd(int a,int b){
        while (b!=0){
            int temp;
            temp=b;
            b=a%b;
            a=temp;
        }
        return a ;
    }
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int a= sc.nextInt();
        int b=sc.nextInt();
        int k=gcd(a,b);

        int lcm=(a*b)/k;
        System.out.println(lcm);

    }
}
