import java.util.*;

public class Problem_06 {
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int[] arr=new int[10];

        for(int i=0;i<10;i++){
            arr[i]=sc.nextInt();

        }
     for(int i=0;i<10;i++){
         if(arr[i] % 3==0){
             System.out.println(arr[i]);
         }
         else if(arr[i] % 5==0){
             System.out.println(arr[i]);
         }
     }
    }
}
