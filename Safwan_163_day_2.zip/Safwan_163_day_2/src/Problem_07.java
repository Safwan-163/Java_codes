import java.lang.classfile.attribute.SyntheticAttribute;
import java.util.Scanner;

public class Problem_07 {

    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
         int a=sc.nextInt();
         int sum=0;
         int digit;
        while (a>0){
            digit =a % 10;
            a=a/10;
            if (digit%2==0){
                sum=sum+digit;

            }

    }
        System.out.println(sum);
    }
}
