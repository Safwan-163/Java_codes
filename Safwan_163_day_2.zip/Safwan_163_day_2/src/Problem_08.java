import java.util.Scanner;

public class Problem_08 {
    static int fact(int a){
        // Base Case: stops the recursion
        if (a <= 1) {
            return 1;
        }
        // Recursive Step: calls the function again with a smaller problem
        else {
            return a * fact(a - 1);
        }

    }
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int k=fact(a);
        System.out.println(k);

    }
}
