import java.util.Scanner;

public class Problem_10 {
    static int max(int arr[],int n){
        int temp=arr[0];
        for(int i=0;i<n;i++){
            if(arr[i]>temp){
                temp=arr[i];
            }
        }
        return temp;

    }
    static int min(int arr[],int n){
        int temp=arr[0];
        for(int i=0;i<n;i++){
            if(arr[i]<temp){
                temp=arr[i];
            }
        }
        return temp;
    }
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int n= sc.nextInt();
        int[] arr=new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        int k=max(arr,n);
        int l=min(arr,n);
        System.out.println("max is" +k);
        System.out.println("min is"+l);


    }
}
