import java.util.Scanner;

public class day_2_lab_practice
{
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);

    }
}
