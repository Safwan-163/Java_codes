import java.util.Scanner;

public class problem_01 {
    public static  void main(String[] arg){

        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int sqr=a*a;
        System.out.println(sqr);

    }
}
