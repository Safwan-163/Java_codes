public class Course_1
{
    String course_name;
    String course_id;
    double credit;

}
