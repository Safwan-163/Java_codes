public class Student {
    String name;
    String id;
    Course[] enrolledCourses;
    int courseCount;


    public Student(String name, String id) {
        this.name = name;
        this.id = id;
        this.enrolledCourses = new Course[10]; // max 10 courses
        this.courseCount = 0;
    }


    public void enrollCourse(Course course) {


        for (int i = 0; i < courseCount; i++) {
            if (enrolledCourses[i].courseCode.equalsIgnoreCase(course.courseCode)) {
                System.out.println("Course already enrolled!");
                return;
            }
        }


        if (courseCount < enrolledCourses.length) {
            enrolledCourses[courseCount] = course;
            courseCount++;
            System.out.println("Course enrolled successfully!");
        } else {
            System.out.println("Cannot enroll. Course limit reached!");
        }
    }


    public void displayEnrolledCourses() {

        if (courseCount == 0) {
            System.out.println("No courses enrolled yet.");
            return;
        }

        System.out.println("Enrolled Courses:");
        for (int i = 0; i < courseCount; i++) {
            enrolledCourses[i].displayInfo();
        }
    }


    public void displayInfo() {
        System.out.println("Student Name : " + name);
        System.out.println("Student ID   : " + id);
        displayEnrolledCourses();
    }

}
