public class Student_1
{
    String name;
    String id;
    course[] enrolled_courses;

}
