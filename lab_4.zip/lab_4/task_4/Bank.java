import java.util.Scanner;
public class Bank {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = sc.nextLine();

        System.out.print("Enter account id: ");
        int id = sc.nextInt();

        System.out.print("Enter initial balance: ");
        double balance = sc.nextDouble();

        BankAccount acc = new BankAccount(name, id, balance);

        int choice;

        do {
            System.out.println("Press 1 for Deposit money");
            System.out.println("Press 2 for  Withdraw money");
            System.out.println("Press 3 for  Check balance");
            System.out.println("Press 4 for  Display account info");
            System.out.println("Press 5 for  Exit");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter deposit amount: ");
                    double dep = sc.nextDouble();
                    acc.deposit(dep);
                    break;

                case 2:
                    System.out.print("Enter withdraw amount: ");
                    double wit = sc.nextDouble();
                    acc.withdraw(wit);
                    break;

                case 3:
                    System.out.println("Current balance: " + acc.getBalance());
                    break;

                case 4:
                    acc.displayInfo();
                    break;

                case 5:
                    System.out.println("Exiting system");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while (choice != 5);
    }
}
