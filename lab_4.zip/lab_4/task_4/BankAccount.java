public class BankAccount {
    public String name;
    public int ID;
    public double balance;

    BankAccount(String name, int ID, double balance){
        this.name = name;
        this.ID = ID;
        this.balance = balance;
    }

    public void deposit(double depAmmount){
        this.balance += depAmmount;
        System.out.println("Deposit successful");
    }

    public void withdraw(double withAmount) {
        if( withAmount <= this.balance) {
            this.balance -=  withAmount;
            System.out.println("Withdrawal successful");
        }
        else {
            System.out.println("Invalid Balance");
        }
    }
    public double getBalance() {
        return this.balance;
    }
    public void displayInfo() {
        System.out.println("Name: " +name+"   Account ID: " +ID+"     Balance: "+balance );
    }

}
