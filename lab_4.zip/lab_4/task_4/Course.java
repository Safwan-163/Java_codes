class Course {
    String courseName;
    String courseCode;
    double credit;


    Course(String courseName, String courseCode, double credit) {
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.credit = credit;
    }


    public void displayInfo() {
        System.out.println("Course Name  : " + courseName);
        System.out.println("Course Code  : " + courseCode);
        System.out.println("Credit       : " + credit);
    }
}
