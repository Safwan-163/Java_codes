class Student {
    String name;
    String id;
    Course enrolledCourse;


    Student(String name, String id) {
        this.name = name;
        this.id = id;
        this.enrolledCourse = null;
    }


    public void enrollCourse(Course course) {
        this.enrolledCourse = course;
        System.out.println("Course enrolled successfully!");
    }


    public void displayInfo() {
        System.out.println("Student Name : " + name);
        System.out.println("Student ID   : " + id);

        if (enrolledCourse != null) {
            System.out.println("Enrolled Course Details:");
            enrolledCourse.displayInfo();
        } else {
            System.out.println("No course enrolled yet.");
        }
    }
}