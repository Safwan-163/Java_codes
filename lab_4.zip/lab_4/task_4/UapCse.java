import java.util.Scanner;
public class UapCse {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);


        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Student ID: ");
        String id = sc.nextLine();

        Student st1 = new Student(name, id);

        int choice;

        do {
            System.out.println("\n.......UAP CSE Student Course Record System .....");
            System.out.println("1. Enroll a Course");
            System.out.println("2. Display Student Details");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Course Name: ");
                    String courseName = sc.nextLine();

                    System.out.print("Enter Course Code: ");
                    String courseCode = sc.nextLine();

                    System.out.print("Enter Course Credit: ");
                    double credit = sc.nextDouble();
                    sc.nextLine();

                    Course course = new Course(courseName, courseCode, credit);
                    st1.enrollCourse(course);
                    break;

                case 2:
                    st1.displayInfo();
                    break;

                case 3:
                    System.out.println("Exiting system...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 3);

        sc.close();
    }
}
